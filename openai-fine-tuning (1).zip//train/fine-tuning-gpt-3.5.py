# -*- coding: utf-8 -*-
import argparse
import openai 
import time
import csv
import os

class OpenaiFinetune():
    def __init__(self, api_key, api_base, n_epochs):
        self.n_epochs = n_epochs
        self.api_key = api_key 
        self.api_base = api_base

        openai.api_key = api_key 
        openai.api_base = api_base

    # 上传文件
    def upload_file(self, file_path):
        file_name = os.path.basename(train_dataset_file)
        result = openai.File.create(
            file=open(file_path, "rb"),
            purpose='fine-tune',
            user_provided_filename = file_name
            )
        print(f"create file {file_path}, result:", result)
        if result["status"] == "uploaded":
            print(f"文件 {file_path} 上传中...")
        return result["id"]

    # 查询file_id的文件是否处理完成  processed
    def check_file_process_done(self, file_id):
        process_success = False
        while process_success == False:
            file_lists = openai.File.list()["data"]
            for file in file_lists:
                if file["id"] == file_id and file["status"] == "processed":
                    filename = file["filename"]
                    print(f"文件 {filename} 上传并处理成功。对应的文件 id 为 {file_id}")
                    file_id = file["id"]
                    process_success = True
                    break
            time.sleep(1)

    # 创建训练任务，根据上传文件时获得的文件id
    def create_train_job(self,train_file_id, valid_file_id, suffix = None):
        if valid_file_id is None:
            result = openai.FineTuningJob.create(training_file=train_file_id,
                                    model="gpt-3.5-turbo",
                                    hyperparameters= {"n_epochs": self.n_epochs},
                                    suffix = suffix)
        else:
            result = openai.FineTuningJob.create(training_file=train_file_id, 
                                    validation_file = valid_file_id,
                                    model="gpt-3.5-turbo",
                                    hyperparameters= {"n_epochs": self.n_epochs},
                                    suffix = suffix)
        print("result:",result)
        job_id = result["id"]
        if result["status"]=="created":
            print(f"训练任务创建成功,id为{job_id}")
        return job_id

    # 查询训练任务直到处理完成
    def check_train_job_done(self, job_id):
        tarin_success = False
        while tarin_success == False:
            job = openai.FineTuningJob.retrieve(job_id)
            # 训练完成后状态变为 succeeded
            if job["id"] == job_id and job["status"] == "succeeded":
                fine_tuned_model = job["fine_tuned_model"]
                result_files = job["result_files"]
                print(f"训练任务{job_id}训练完成，得到模型: {fine_tuned_model}, 训练过程文件: {result_files}")
                tarin_success = True
                break
            else:
                print(f"训练任务{job_id}仍在训练中...")
            time.sleep(10)
        return fine_tuned_model, result_files

    # 根据训练得到的result_files，将训练过程的结果文件保存在save_dir下
    def save_result_file(self, model_name, result_files, save_dir):
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)

        for result_file in result_files:
            data = openai.File.download(result_file)
            # 将字节串转换为字符串
            data_str = data.decode('utf-8')

            # 将字符串分割为行
            lines = data_str.split('\n')

            # 保存模型名称
            file_name = os.path.join(save_dir, result_file + '.model_name')
            with open(file_name, 'a+', newline = '') as file:
                file.write(model_name)

            # 打开一个新的CSV文件并写入数据
            file_name = os.path.join(save_dir, result_file + '.csv')
            with open(file_name, 'a+', newline = '') as file:
                writer = csv.writer(file)
                for line in lines:
                    # 将每一行的数据分割为单独的字段
                    fields = line.split(',')
                    # 写入一行数据
                    writer.writerow(fields)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Process some integers.')
    parser.add_argument('--train_dataset_file', type=str, required=True, help='path to the training dataset file')
    parser.add_argument('--valid_dataset_file', type=str, help='path to the validation dataset file')
    parser.add_argument('--api_key', type=str, required=True, help='openai api_key')
    parser.add_argument('--n_epochs', type=int, required=True, help='train epochs')
    args = parser.parse_args()
    train_dataset_file = args.train_dataset_file
    valid_dataset_file = args.valid_dataset_file
    n_epochs = args.n_epochs
    api_key = args.api_key

    # 初始化OpenaiFinetune实例
    api_base = "https://api.openai.com/v1"
    ft = OpenaiFinetune(api_key, api_base, n_epochs)

    # 上传训练数据
    train_file_id = ft.upload_file(train_dataset_file)
    ft.check_file_process_done(train_file_id)

    # 开始执行评测文档上传
    if valid_dataset_file == None:
        valid_file_id = None
        print("No valid dataset file ...")
    else:
        valid_file_id = ft.upload_file(valid_dataset_file)
        ft.check_file_process_done(valid_file_id)

    # train_file_id = "file-mHXefSyLYTtRsGnpPqP8R3sr"
    # valid_file_id = "file-qvcm7yd76RYhen9buissd5vA"
    print(f"train_file_id is: {train_file_id}, valid_file_id is: {valid_file_id}")

    # 创建训练任务
    job_id = ft.create_train_job(train_file_id, valid_file_id, suffix = None)
    print("训练任务的job_id:",job_id) # "ftjob-AjRonYP4hkBhf8AL9cAaR3N4"

    # 不断循环查询训练任务是否执行完成，将持续占用
    fine_tuned_model, result_files = ft.check_train_job_done(job_id)

    # 自定义训练结果保存地址
    # 将训练结果保存在save_dir中
    ft.save_result_file(fine_tuned_model, result_files, save_dir = "output")
