# -*- coding: utf-8 -*-
import argparse
import openai 
import time
import csv
import os
import json

def do_eval(eval_dataset_file, model_name):
    save_dir = "output"
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    eval_file_name = os.path.basename(eval_dataset_file)
    output_file =  os.path.join(save_dir, eval_file_name + "_output.json")

    num = 0
    try:
        with open(output_file, 'w+') as f_output:
            print(eval_dataset_file)
            with open(eval_dataset_file, 'r') as f_input:
                for line in f_input:
                    obj = json.loads(line)
                    print(f"evaluating {line} ...")
                    completion = openai.ChatCompletion.create(
                        model = model_name,
                        messages = obj["messages"]
                    )
                    num += 1
                    f_output.write(json.dumps(completion.choices[0].message)+ '\n')
    except Exception as e:
        print(str(e))
    print(f"<<<<<<< evaluated {num} items! results in file: {output_file} >>>>>>")

if __name__ == '__main__':
    openai.api_key = "1696718940967436327"
    openai.api_base = "https://aigc.sankuai.com/v1/openai/ft"

    parser = argparse.ArgumentParser(description='')
    parser.add_argument('--eval_dataset_file', type=str, required=True, help='path to the eval dataset file')
    parser.add_argument('--model_name', type=str, required=True, help='fine tuned model name')
    args = parser.parse_args()

    eval_dataset_file = args.eval_dataset_file
    model_name = args.model_name

    do_eval(eval_dataset_file, model_name)
